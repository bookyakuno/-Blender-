#  This program is free software; you can redistribute it and/or
#  modify it under the terms of the GNU General Public License
#  as published by the Free Software Foundation; either version 2
#  of the License, or (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software Foundation,
#  Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.

import sys

from . import w_pie
from . import add_pie
from . import uv_pie
# from . import prefs
from bpy.types import Operator, AddonPreferences

import bpy, os
from bpy.types import Menu, Header
from bpy.props import IntProperty, FloatProperty, BoolProperty
import bmesh
from mathutils import *
import math



bl_info = {
    "name": "w_pie",
    "author": "Bookyakuno & Cédric Lepiller & Jimmy & DavideDozza & Lapineige & Leafar & 0rAngE",
    "version": (0, 2, 3),
    "blender": (2, 79, 0),
    "description": "Custom Pie Menus",
    "category": "3D View",}


def _call_globals(attr_name):
    for m in globals().values():
        if hasattr(m, attr_name):
            getattr(m, attr_name)()


def _flush_modules(pkg_name):
    pkg_name = pkg_name.lower()
    for k in tuple(sys.modules.keys()):
        if k.lower().startswith(pkg_name):
            del sys.modules[k]








class w_pie_Prefs(bpy.types.AddonPreferences):

    bl_idname = __name__

    bpy.types.Scene.Enable_Tab_01 = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.Enable_Tab_02 = bpy.props.BoolProperty(default=False)
    bpy.types.Scene.Enable_Tab_03 = bpy.props.BoolProperty(default=False)

    def draw(self, context):
        layout = self.layout

        layout.prop(context.scene, "Enable_Tab_01", text="Info", icon="QUESTION")
        if context.scene.Enable_Tab_01:
            row = layout.row()
            layout.label(text="This add-on is a compact modified 'wazou pie menu'and added functions.")
            layout.label(text="> Wazou Pie Menus")
            layout.label(text="> Jimmy_pie_uv")
            layout.label(text="> Add Object Pie Menu")
            layout.label(text="")
            layout.label(text="-shortcut-")

            # このアドオンは、"wazou pie menu" をコンパクトに改造し、さらに機能を追加したものです。
            # >右クリックからの呼び出し
            # >"新規オブジェクト追加 pie"
            # >"UV pie"を追加


            # layout.label(text="This Addon Need to activate 'Loop Tools' and 'Bsurfaces' in the Addon Tab to work properly.")
            # layout.label(text="You need to install Iceking's Tool And Auto Mirror")
            #
            # layout.operator("wm.url_open", text="IceKing's tools").url = "http://www.blenderartists.org/forum/showthread.php?343641-Iceking-s-Tools"
            # layout.operator("wm.url_open", text="Auto Mirror").url = "http://le-terrier-de-lapineige.over-blog.com/2014/07/automirror-mon-add-on-pour-symetriser-vos-objets-rapidement.html"
        #
        # layout.prop(context.scene, "Enable_Tab_02", text="Shortcuts", icon="QUESTION")
        # if context.scene.Enable_Tab_02:



            layout = self.layout
            scene = context.scene
            cscene = scene.cycles
            rd = context.scene.render



            col = layout.column(align=True)


            # col = split.column()
            row = col.row(align=True)
            row.label(text="– Object/Edit mode & Vertex/Edge/face >", icon='FACESEL')
            row.label(text="Right mouse")

            split = layout.split()
            row = col.row(align=True)
            row.label(text="– add object >", icon='MONKEY')
            row.label(text="Right mouse + shift")

            split = layout.split()
            row = col.row(align=True)
            row.label(text="– Shading >", icon='MATERIAL')
            row.label(text="Right mouse + shift + alt")

            split = layout.split()
            row = col.row(align=True)
            row.label(text="– Pivot point   >", icon='ROTATECOLLECTION')
            row.label(text="Right mouse + alt")


            split = layout.split()
            row = col.row(align=True)
            row.label(text="– Views >", icon='NODETREE')
            row.label(text="Ctrl + Q")

            split = layout.split()
            row = col.row(align=True)
            row.label(text="– Views misc>", icon='NODETREE')
            row.label(text="Ctrl + shift + Q")

            split = layout.split()
            row = col.row(align=True)
            row.label(text="– Cursor/Origin >", icon='CURSOR')
            row.label(text="Shift + S")

            split = layout.split()
            row = col.row(align=True)
            row.label(text="– Selections >", icon='BORDER_RECT')
            row.label(text="Shift + G")

            split = layout.split()
            row = col.row(align=True)
            row.label(text="– UV >", icon='OUTLINER_OB_LATTICE')
            row.label(text="ctrl D")




        layout.prop(context.scene, "Enable_Tab_03", text="URL's", icon="URL")
        if context.scene.Enable_Tab_03:
            row = layout.row()
            row.operator("wm.url_open", text="Pitiwazou.com").url = "http://www.pitiwazou.com/"
            row.operator("wm.url_open", text="Wazou's Ghitub").url = "https://github.com/pitiwazou/Scripts-Blender"
            row.operator("wm.url_open", text="BlenderLounge Forum ").url = "http://blenderlounge.fr/forum/"
            row = layout.row()
            row.operator("wm.url_open", text="bookyakuno github").url = "https://github.com/bookyakuno/-Blender-/blob/master/w_pie.zip"



addon_keymaps = []

def register():
    bpy.utils.register_class(w_pie_Prefs)
    bpy.utils.register_module(__name__)


# Keympa Config

    wm = bpy.context.window_manager

    if wm.keyconfigs.addon:
        #Select Mode
        km = wm.keyconfigs.addon.keymaps.new(name='Object Non-modal')
        kmi = km.keymap_items.new('wm.call_menu_pie', 'RIGHTMOUSE', 'PRESS')
        kmi.properties.name = "pie.objecteditmode"

        #Views
        km = wm.keyconfigs.addon.keymaps.new(name='Window')
        kmi = km.keymap_items.new('wm.call_menu_pie', 'Q', 'PRESS', ctrl=True)
        kmi.properties.name = "pie.areaviews"
        #Views
        km = wm.keyconfigs.addon.keymaps.new(name='Window')
        kmi = km.keymap_items.new('wm.call_menu_pie', 'Q', 'PRESS', ctrl=True, shift=True)
        kmi.properties.name = "pie.view_misc"

        #Origin/Pivot
        km = wm.keyconfigs.addon.keymaps.new(name = '3D View Generic', space_type = 'VIEW_3D')
        kmi = km.keymap_items.new('wm.call_menu_pie', 'RIGHTMOUSE', 'PRESS', alt=True)
        kmi.properties.name = "pie.originpivot"

        # cursor
        km = wm.keyconfigs.addon.keymaps.new(name = '3D View Generic', space_type = 'VIEW_3D')
        kmi = km.keymap_items.new('wm.call_menu_pie', 'S', 'PRESS', shift=True)
        kmi.properties.name = "pie.originpivot"
        km = wm.keyconfigs.addon.keymaps.new(name = 'Mesh')
        kmi = km.keymap_items.new('wm.call_menu_pie', 'S', 'PRESS', shift=True)
        kmi.properties.name = "pie.originpivot"

        #Shading
        km = wm.keyconfigs.addon.keymaps.new(name = '3D View Generic', space_type = 'VIEW_3D')
        kmi = km.keymap_items.new('wm.call_menu_pie', 'RIGHTMOUSE', 'PRESS', alt=True, shift=True)
        kmi.properties.name = "pie.shadingview"

        #Object shading
        # km = wm.keyconfigs.addon.keymaps.new(name = '3D View Generic', space_type = 'VIEW_3D')
        # kmi = km.keymap_items.new('wm.call_menu_pie', 'Z', 'PRESS', shift=True)
        # kmi.properties.name = "pie.objectshading"

        #Selection Object Mode
        km = wm.keyconfigs.addon.keymaps.new(name = 'Object Mode')
        kmi = km.keymap_items.new('wm.call_menu_pie', 'G', 'PRESS', shift=True)
        kmi.properties.name = "pie.selectionsom"

        #Selection Edit Mode
        km = wm.keyconfigs.addon.keymaps.new(name = 'Mesh')
        kmi = km.keymap_items.new('wm.call_menu_pie', 'G', 'PRESS', shift=True)
        kmi.properties.name = "pie.selectionsem"

        #uv_pie
        km = wm.keyconfigs.addon.keymaps.new(name = 'Mesh')
        kmi = km.keymap_items.new('wm.call_menu_pie', 'D', 'PRESS', ctrl=True)
        kmi.properties.name = "pie.uv_pie"

        #uv_pie
        km = wm.keyconfigs.addon.keymaps.new(name = 'Image', space_type='IMAGE_EDITOR')
        kmi = km.keymap_items.new('wm.call_menu_pie', 'D', 'PRESS', ctrl=True)
        kmi.properties.name = "pie.uv_pie"






        #Keymaps


        wm = bpy.context.window_manager

        km = wm.keyconfigs.addon.keymaps.new(name = "Node Editor", space_type = "NODE_EDITOR")
        kmi = km.keymap_items.new("wm.call_menu_pie", "RIGHTMOUSE", "PRESS", shift=True)
        kmi.properties.name="pie.add_node"
        addon_keymaps.append(km)


        km = wm.keyconfigs.addon.keymaps.new(name="Object Mode")
        kmi = km.keymap_items.new("wm.call_menu_pie", "RIGHTMOUSE", "PRESS", shift=True)
        kmi.properties.name="add.menu"
        addon_keymaps.append(km)
        print(kmi.properties.name)

        #mesh edit mode
        km = wm.keyconfigs.addon.keymaps.new(name="Mesh")
        kmi = km.keymap_items.new("wm.call_menu_pie", "RIGHTMOUSE", "PRESS", shift=True)
        kmi.properties.name="add.mesh"
        addon_keymaps.append(km)
        print(kmi.properties.name)

        #curve edit mode
        km = wm.keyconfigs.addon.keymaps.new(name="Curve")
        kmi = km.keymap_items.new("wm.call_menu_pie", "RIGHTMOUSE", "PRESS", shift=True)
        kmi.properties.name="add.curve"
        addon_keymaps.append(km)
        print(kmi.properties.name)

        #mataball edit mode
        km = wm.keyconfigs.addon.keymaps.new(name="Metaball")
        kmi = km.keymap_items.new("wm.call_menu_pie", "RIGHTMOUSE", "PRESS", shift=True)
        kmi.properties.name="add.metaball"
        addon_keymaps.append(km)

        print(kmi.properties.name)



        # UV pie
        km = wm.keyconfigs.addon.keymaps.new('UV Editor', space_type='EMPTY', region_type='WINDOW', modal=False)
        # km = wm.keyconfigs.addon.keymaps.new(name='Image',space_type='IMAGE_EDITOR')
        kmi = km.keymap_items.new('wm.call_menu_pie', 'ACTIONMOUSE', 'ANY')
        kmi.properties.name = "pie.uv_select_mode"

        addon_keymaps.append(km)








# Register / Unregister Classes
def unregister():
    bpy.utils.unregister_class(w_pie_Prefs)
    bpy.utils.unregister_module(__name__)

if __name__ == "__main__":
    register()
